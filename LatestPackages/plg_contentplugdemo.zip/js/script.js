//your js here
//be sure to uncomment registerAndUseScript... in php file